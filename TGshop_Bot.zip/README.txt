# 🛍️ PowerXShop Telegram Bot

A fully automated Telegram e-commerce bot designed to sell digital JSON files (Meesho ₹170 Off and Swiggy ₹160+ Cash). The bot features an integrated UPI payment gateway, manual payment approval, a referral points system, and a powerful Inline Admin Panel.

## ✨ Features
- **Product Catalog:** Beautifully styled inline menus for purchasing.
- **Automated Checkout:** Generates custom UPI QR codes and direct app links.
- **Smart JSON Delivery:** Automatically detects the quantity purchased. If buying 4+ accounts, it sends the codes in a `.txt` file to bypass Telegram's 4096-character limit error.
- **Refer & Earn:** Users get a unique link. When they invite friends, they earn points which can be redeemed for free stock.
- **Force Join:** Users must join your specified update channels before using the shop.
- **Inline Admin Panel:** View live stats and add new stock directly by uploading a `.txt` file.
- **Broadcast System:** Send messages to all users using `/broadcast <text>` or by replying to a `.txt` file with `/broadcast`.

---

## 📦 Requirements & Dependencies

Make sure you have **Python 3.10 or higher** installed. 

Create a file named `requirements.txt` in the same folder as `tgshopx.py` and paste the following inside:
```text
python-telegram-bot>=20.7
pytz>=2023.3
requests>=2.31.0