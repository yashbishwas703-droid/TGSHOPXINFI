import logging
import os
import re
import json
import html
import uuid
import io
import asyncio
from datetime import datetime
import pytz
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from telegram.error import TelegramError

# ── Custom Button Styling (From Swiggy Diya) ──────────────────────────────────
try:
    from telegram.constants import KeyboardButtonStyle
    STYLE_P = KeyboardButtonStyle.PRIMARY     # blue
    STYLE_S = KeyboardButtonStyle.SUCCESS     # green
    STYLE_D = KeyboardButtonStyle.DANGER      # red
except Exception:
    STYLE_P, STYLE_S, STYLE_D = "primary", "success", "danger"

ICO_BLUE = "5373141891321699086"
ICO_RED = "5370810157871667232"
ICO_GREEN = "5471984997361523302"
ICO_UNLOCK = "5359664288241829619"
ICO_CANCEL = "5382224089295365367"
ICO_RENEW = "5891063600885273198"

def btn(text, data, style=None, icon=None):
    if str(data).startswith(("http://", "https://")):
        try:
            return InlineKeyboardButton(text, url=data)
        except TypeError:
            pass
    kw = {"callback_data": data}
    if style:
        kw["style"] = style
    if icon:
        kw["icon_custom_emoji_id"] = icon
    try:
        return InlineKeyboardButton(text, **kw)
    except TypeError:
        return InlineKeyboardButton(text, callback_data=data)

def kb(*rows):
    out = []
    for row in rows:
        line = []
        for spec in row:
            line.append(btn(spec[0], spec[1],
                            spec[2] if len(spec) > 2 else None,
                            spec[3] if len(spec) > 3 else None))
        out.append(line)
    return InlineKeyboardMarkup(out)

# Enable logging
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

# 🛑 CONFIGURATION - UPDATED UPI & ADMINS
BOT_TOKEN = "8725961285:AAHz4XOrPvDzM9uinW2EYVJ1ta8T5GaO1_Q"
UPI_ID = "9415235805@upi"                  
MERCHANT_NAME = "PowerXShop"  

# 📢 FORCE JOIN CHANNELS
REQUIRED_CHANNELS = [
    {"username": "@EarningXPowers", "url": "https://t.me/EarningXPowers"},
    {"username": "@PowerXDiscuss", "url": "https://t.me/PowerXDiscuss"}
]

# 🌟 DUAL ADMIN CONFIGURATION
ADMIN_IDS = [7818023479, 1879784162]

# 🛍️ PRODUCT DATABASE
PRODUCTS = {
    "meesho_170": {
        "name": "💜 ᴍᴇᴇsʜᴏ ₹170 ᴏғғ ᴊsᴏɴ", 
        "price": 19.0,
        "file": "meesho_170.txt",
        "type": "coupon",
        "lines_per_unit": 1
    },
    "swiggy_160": {
        "name": "💙 sᴡɪɢɢʏ ₹160+ ᴄᴀsʜ ᴊsᴏɴ", 
        "price": 12.0,
        "file": "swiggy_160.txt",
        "type": "coupon",
        "lines_per_unit": 1
    }
}

# 🎁 REDEEMABLE REFERRAL ITEMS
REDEEM_PRODUCTS = {
    "swiggy_160_redeem": {
        "name": "💙 sᴡɪɢɢʏ ₹160+ ᴄᴀsʜ ᴊsᴏɴ",
        "points_cost": 2,
        "file": "swiggy_160.txt"
    }
}

USER_DB_FILE = "users.txt"
PROMO_TRACKER_FILE = "promo_usage.txt"
ADMIN_ORDERS_LOG = "admin_orders.json"
REFERRAL_DB_FILE = "referral_data.json"  
SALES_STATS_FILE = "sales_stats.json"
PENDING_UPLOADS_FILE = "pending_users.json"
VALID_PROMO_CODE = "INFINITY ALWAYS 🫆"

def get_file_path(file_name: str) -> str:
    cwd_path = os.path.join(os.getcwd(), file_name)
    if os.path.exists(cwd_path):
        return cwd_path
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(script_dir, file_name)

def calculate_item_total(product_key: str, quantity: int) -> tuple[float, float]:
    product = PRODUCTS[product_key]
    if product.get("price_tiered"):
        if quantity >= product.get("bulk_threshold", 5):
            unit_rate = product["bulk_price"]
        else:
            unit_rate = product["base_price"]
    else:
        unit_rate = product["price"]
    
    return unit_rate * quantity, unit_rate

def get_ist_time_details():
    tz = pytz.timezone("Asia/Kolkata")
    now = datetime.now(tz)
    date_str = now.strftime("%d-%b-%Y")
    full_time_str = now.strftime("%d-%b-%Y | %I:%M %p IST")
    return date_str, full_time_str

def get_stock_count(file_name: str, lines_per_unit: int = 1) -> int:
    if file_name == USER_DB_FILE:
        return 0
    filepath = get_file_path(file_name)
    if not os.path.exists(filepath):
        return 0
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read().strip()
            if not content:
                return 0
            decoder = json.JSONDecoder()
            pos = 0
            count = 0
            while pos < len(content):
                while pos < len(content) and content[pos].isspace():
                    pos += 1
                if pos >= len(content):
                    break
                try:
                    _, index = decoder.raw_decode(content, pos)
                    count += 1
                    pos = index
                except json.JSONDecodeError:
                    return len([line.strip() for line in content.split("\n") if line.strip()])
            return count
    except Exception as e:
        logging.error(f"Error reading stock file {file_name}: {e}")
        return 0

def save_user(user_id: int):
    filepath = get_file_path(USER_DB_FILE)
    existing_users = []
    if os.path.exists(filepath):
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            existing_users = [line.strip() for line in f.readlines()]
    if str(user_id) not in existing_users:
        with open(filepath, "a", encoding="utf-8") as f:
            f.write(f"{user_id}\n")

def load_pending_uploads() -> dict:
    filepath = get_file_path(PENDING_UPLOADS_FILE)
    if not os.path.exists(filepath):
        return {}
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_pending_uploads(data: dict):
    filepath = get_file_path(PENDING_UPLOADS_FILE)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f)

def load_referral_data() -> dict:
    filepath = get_file_path(REFERRAL_DB_FILE)
    if not os.path.exists(filepath):
        return {}
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_referral_data(data: dict):
    filepath = get_file_path(REFERRAL_DB_FILE)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f)

def load_sales_stats() -> dict:
    filepath = get_file_path(SALES_STATS_FILE)
    if not os.path.exists(filepath):
        return {}
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_sales_stats(data: dict):
    filepath = get_file_path(SALES_STATS_FILE)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f)

def record_sales_stat(user_id: int, username: str, product_key: str, quantity: int, revenue: float):
    stats = load_sales_stats()
    date_str, full_time_str = get_ist_time_details()
    user_str = str(user_id)

    if date_str not in stats or not isinstance(stats[date_str], dict):
        stats[date_str] = {
            "daily_revenue": 0.0,
            "items_sold": {},
            "orders": []
        }
    
    stats[date_str]["daily_revenue"] += revenue
    
    if product_key not in stats[date_str]["items_sold"]:
        stats[date_str]["items_sold"][product_key] = 0
    stats[date_str]["items_sold"][product_key] += quantity

    stats[date_str]["orders"].append({
        "user_id": user_str,
        "username": username or "Unknown User",
        "product_key": product_key,
        "product_name": PRODUCTS.get(product_key, {}).get("name", product_key),
        "quantity": quantity,
        "amount": revenue,
        "time": full_time_str
    })
    
    save_sales_stats(stats)

def init_user_referral(user_id: str, referrer_id: str = None):
    db = load_referral_data()
    if user_id not in db:
        db[user_id] = {
            "points": 0,
            "referred_by": referrer_id,
            "claimed_reward": False if referrer_id else True 
        }
        save_referral_data(db)

def process_pending_referral_reward(user_id: str) -> str:
    db = load_referral_data()
    if user_id in db and not db[user_id]["claimed_reward"]:
        referrer = db[user_id]["referred_by"]
        if referrer in db:
            db[referrer]["points"] += 1
            db[user_id]["claimed_reward"] = True
            save_referral_data(db)
            return referrer
    return None

def get_promo_uses() -> int:
    filepath = get_file_path(PROMO_TRACKER_FILE)
    if not os.path.exists(filepath):
        return 0
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        return len([line.strip() for line in f.readlines() if line.strip()])

def record_promo_use(user_id: int):
    filepath = get_file_path(PROMO_TRACKER_FILE)
    with open(filepath, "a", encoding="utf-8") as f:
        f.write(f"{user_id}\n")

def extract_and_remove_codes(file_name: str, quantity: int, lines_per_unit: int = 1) -> list:
    if file_name == USER_DB_FILE:
        return []
    filepath = get_file_path(file_name)
    if not os.path.exists(filepath):
        return []

    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read().strip()

    if not content:
        return []

    # Smart Parser
    decoder = json.JSONDecoder()
    pos = 0
    objects = []
    
    while pos < len(content):
        while pos < len(content) and content[pos].isspace():
            pos += 1
        if pos >= len(content):
            break
        try:
            obj, index = decoder.raw_decode(content, pos)
            objects.append((obj, content[pos:index].strip()))
            pos = index
        except json.JSONDecodeError:
            break

    if objects and len(objects) >= quantity:
        selected_raw = [obj[1] for obj in objects[:quantity]]
        remaining_raw = [obj[1] for obj in objects[quantity:]]

        with open(filepath, "w", encoding="utf-8") as f:
            for rem in remaining_raw:
                f.write(rem + "\n\n")

        return selected_raw

    # Fallback
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        all_lines = [line.strip() for line in f.readlines() if line.strip()]
        
    total_lines_needed = quantity * lines_per_unit
    if len(all_lines) < total_lines_needed:
        return []
        
    selected_lines = all_lines[:total_lines_needed]
    remaining_lines = all_lines[total_lines_needed:]
    
    with open(filepath, "w", encoding="utf-8") as f:
        for line in remaining_lines:
            f.write(f"{line}\n")
            
    return selected_lines

def load_admin_orders() -> dict:
    filepath = get_file_path(ADMIN_ORDERS_LOG)
    if not os.path.exists(filepath):
        return {}
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_admin_orders(data: dict):
    filepath = get_file_path(ADMIN_ORDERS_LOG)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f)

async def check_membership(user_id: int, bot) -> bool:
    for ch in REQUIRED_CHANNELS:
        try:
            member = await bot.get_chat_member(chat_id=ch["username"], user_id=user_id)
            if member.status not in ["member", "administrator", "creator"]:
                return False
        except TelegramError:
            return False
    return True

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.message.from_user.id)
    save_user(int(user_id))
    
    if context.args and context.args[0].isdigit():
        referrer_id = context.args[0]
        if referrer_id != user_id:  
            init_user_referral(user_id, referrer_id)
            
    init_user_referral(user_id) 
    
    is_member = await check_membership(int(user_id), context.bot)

    if not is_member:
        keyboard = []
        for ch in REQUIRED_CHANNELS:
            keyboard.append([btn(f"📢 ᴊᴏɪɴ {ch['username']}", ch["url"], STYLE_P, ICO_BLUE)])
        keyboard.append([btn("🔄 ᴅᴏɴᴇ / sᴛᴀʀᴛ ᴀɢᴀɪɴ", "check_join", STYLE_S, ICO_RENEW)])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            "⚠️ <b>ᴀᴄᴄᴇss ᴅᴇɴɪᴇᴅ!</b>\n\nʏᴏᴜ ᴍᴜsᴛ ᴊᴏɪɴ ᴏᴜʀ ᴏғғɪᴄɪᴀʟ ᴜᴘᴅᴀᴛᴇs & ᴅɪsᴄᴜssɪᴏɴ ᴄʜᴀɴɴᴇʟs ʙᴇғᴏʀᴇ ᴀᴄᴄᴇssɪɴɢ ᴛʜᴇ sʜᴏᴘ.",
            reply_markup=reply_markup,
            parse_mode="HTML"
        )
    else:
        referrer_notified = process_pending_referral_reward(user_id)
        if referrer_notified:
            try:
                await context.bot.send_message(
                    chat_id=int(referrer_notified),
                    text="🎉 <b>ɴᴇᴡ ʀᴇғᴇʀʀᴀʟ sᴜᴄᴄᴇss!</b> ᴀ ғʀɪᴇɴᴅ ᴊᴏɪɴᴇᴅ ᴜsɪɴɢ ʏᴏᴜʀ ʟɪɴᴋ. +1 ᴘᴏɪɴᴛ ᴀᴅᴅᴇᴅ!",
                    parse_mode="HTML"
                )
            except TelegramError:
                pass

        main_keyboard = [["🛸 ɢᴏ ᴛᴏ sᴛᴏʀᴇ"], ["🛠️ sᴜᴘᴘᴏʀᴛ"]]
        if int(user_id) in ADMIN_IDS:
            main_keyboard.append(["👑 ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ"])
            
        reply_markup = ReplyKeyboardMarkup(main_keyboard, resize_keyboard=True)
        await update.message.reply_text("✨ ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ <b>ᴘᴏᴡᴇʀxꜱʜᴏᴘ</b> 🚀\n\n<i>ᴜsᴇ ᴛʜᴇ ᴍᴇɴᴜ ʙᴇʟᴏᴡ ᴛᴏ ɴᴀᴠɪɢᴀᴛᴇ.</i>", reply_markup=reply_markup, parse_mode="HTML")

async def check_join_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = str(query.from_user.id)
    
    if await check_membership(int(user_id), context.bot):
        await query.message.delete()
        
        referrer_notified = process_pending_referral_reward(user_id)
        if referrer_notified:
            try:
                await context.bot.send_message(
                    chat_id=int(referrer_notified),
                    text="🎉 <b>ɴᴇᴡ ʀᴇғᴇʀʀᴀʟ sᴜᴄᴄᴇss!</b> ᴀ ғʀɪᴇɴᴅ ᴄᴏᴍᴘʟᴇᴛᴇᴅ ᴠᴇʀɪғɪᴄᴀᴛɪᴏɴ. +1 ᴘᴏɪɴᴛ ᴀᴅᴅᴇᴅ!",
                    parse_mode="HTML"
                )
            except TelegramError:
                pass

        main_keyboard = [["🛸 ɢᴏ ᴛᴏ sᴛᴏʀᴇ"], ["🛠️ sᴜᴘᴘᴏʀᴛ"]]
        if int(user_id) in ADMIN_IDS:
            main_keyboard.append(["👑 ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ"])

        reply_markup = ReplyKeyboardMarkup(main_keyboard, resize_keyboard=True)
        await context.bot.send_message(
            chat_id=query.message.chat_id, 
            text="✅ ᴠᴇʀɪғɪᴄᴀᴛɪᴏɴ sᴜᴄᴄᴇssғᴜʟ! ᴡᴇʟᴄᴏᴍᴇ ʙᴀᴄᴋ.", 
            reply_markup=reply_markup
        )
    else:
        await context.bot.send_message(chat_id=query.message.chat_id, text="❌ ʏᴏᴜ ʜᴀᴠᴇɴ'ᴛ ᴊᴏɪɴᴇᴅ ʙᴏᴛʜ ᴄʜᴀɴɴᴇʟs ʏᴇᴛ! ᴘʟᴇᴀsᴇ ᴊᴏɪɴ ᴛʜᴇᴍ ғɪʀsᴛ.")

async def show_main_categories(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.message.from_user.id)
    if not await check_membership(int(user_id), context.bot):
        await start(update, context)
        return

    keyboard = [
        [btn("🌼 ᴅɪsᴄᴏᴜɴᴛᴇᴅ ᴄᴏᴜᴘᴏɴs", "cat_coupons", STYLE_S, ICO_GREEN)],
        [btn("💮 ᴅɪsᴄᴏᴜɴᴛᴇᴅ sᴜʙsᴄʀɪᴘᴛɪᴏɴ", "cat_subs", STYLE_P, ICO_BLUE)],
        [btn("🌺 ʀᴇғᴇʀ ᴀɴᴅ ᴇᴀʀɴ", "refer_earn_menu", STYLE_D, ICO_RED)] 
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    cat_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "🛍️ <b>ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ᴘᴏᴡᴇʀxꜱʜᴏᴘ</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        "<i>ᴘʟᴇᴀsᴇ ᴄʜᴏᴏsᴇ ᴀ ᴘʀᴏᴅᴜᴄᴛ ᴄᴀᴛᴇɢᴏʀʏ ʙᴇʟᴏᴡ:</i> 👇"
    )
    await update.message.reply_text(cat_text, reply_markup=reply_markup, parse_mode="HTML")

async def show_main_categories_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    keyboard = [
        [btn("🌼 ᴅɪsᴄᴏᴜɴᴛᴇᴅ ᴄᴏᴜᴘᴏɴs", "cat_coupons", STYLE_S, ICO_GREEN)],
        [btn("💮 ᴅɪsᴄᴏᴜɴᴛᴇᴅ sᴜʙsᴄʀɪᴘᴛɪᴏɴ", "cat_subs", STYLE_P, ICO_BLUE)],
        [btn("🌺 ʀᴇғᴇʀ ᴀɴᴅ ᴇᴀʀɴ", "refer_earn_menu", STYLE_D, ICO_RED)]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    cat_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "🛍️ <b>ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ᴘᴏᴡᴇʀxꜱʜᴏᴘ</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        "<i>ᴘʟᴇᴀsᴇ ᴄʜᴏᴏsᴇ ᴀ ᴘʀᴏᴅᴜᴄᴛ ᴄᴀᴛᴇɢᴏʀʏ ʙᴇʟᴏᴡ:</i> 👇"
    )
    await query.message.edit_text(cat_text, reply_markup=reply_markup, parse_mode="HTML")

async def display_referral_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = str(query.from_user.id)
    init_user_referral(user_id)
    
    db = load_referral_data()
    current_points = db[user_id]["points"]
    bot_info = await context.bot.get_me()
    
    invite_link = f"https://t.me/{bot_info.username}?start={user_id}"
    
    ref_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "🌺 <b>ʀᴇғᴇʀ ᴀɴᴅ ᴇᴀʀɴ sʏsᴛᴇᴍ</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"📊 <b>ʏᴏᴜʀ ʟɪᴠᴇ ʙᴀʟᴀɴᴄᴇ:</b> <code>{current_points}</code> ᴘᴏɪɴᴛs\n\n"
        "📢 <b>ʜᴏᴡ ɪᴛ ᴡᴏʀᴋs:</b>\n"
        "sʜᴀʀᴇ ʏᴏᴜʀ ᴜɴɪǫᴜᴇ ɪɴᴠɪᴛᴀᴛɪᴏɴ ʟɪɴᴋ ʙᴇʟᴏᴡ. ᴡʜᴇɴ ᴀ ғʀɪᴇɴᴅ ᴊᴏɪɴs ᴀɴᴅ ᴠᴇʀɪғɪᴇs ᴄʜᴀɴɴᴇʟ sᴜʙsᴄʀɪᴘᴛɪᴏɴ, "
        "ʏᴏᴜ ᴡɪʟʟ ʙᴇ ɪɴsᴛᴀɴᴛʟʏ ᴀᴡᴀʀᴅᴇᴅ <b>+1 ʀᴇғᴇʀ ᴘᴏɪɴᴛ</b>!\n\n"
        "🔗 <b>ʏᴏᴜʀ ᴜɴɪǫᴜᴇ ʀᴇғᴇʀʀᴀʟ ʟɪɴᴋ:</b>\n"
        f"<code>{invite_link}</code>\n\n"
        "📌 <i>ᴛᴀᴘ ᴛʜᴇ ʟɪɴᴋ ᴀʙᴏᴠᴇ ᴛᴏ ᴄᴏᴘʏ ɪᴛ ɪɴsᴛᴀɴᴛʟʏ.</i>"
    )
    
    keyboard = [
        [btn("🎗️ ʀᴇᴅᴇᴇᴍ ᴘᴏɪɴᴛs", "redeem_points_store", STYLE_S, ICO_GREEN)],
        [btn("🔙 ʙᴀᴄᴋ ᴛᴏ ᴄᴀᴛᴇɢᴏʀɪᴇs", "back_categories", STYLE_P, ICO_BLUE)]
    ]
    await query.message.edit_text(ref_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")

async def display_redemption_store(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = str(query.from_user.id)
    db = load_referral_data()
    current_points = db.get(user_id, {}).get("points", 0)
    
    keyboard = []
    for r_key, r_item in REDEEM_PRODUCTS.items():
        stock_qty = get_stock_count(r_item["file"])
        btn_label = f"{r_item['name']} [{r_item['points_cost']} Pts] (Stock: {stock_qty})"
        keyboard.append([btn(btn_label, f"claim_{r_key}", STYLE_S, ICO_GREEN)])
        
    keyboard.append([btn("🔙 ʙᴀᴄᴋ ᴛᴏ ʀᴇғᴇʀʀᴀʟ ᴍᴇɴᴜ", "refer_earn_menu", STYLE_P, ICO_BLUE)])
    
    store_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "🎗️ <b>ᴘᴏɪɴᴛs ʀᴇᴅᴇᴍᴘᴛɪᴏɴ ᴄᴇɴᴛʀᴇ</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"📊 <b>ᴀᴠᴀɪʟᴀʙʟᴇ ᴡᴀʟʟᴇᴛ ʙᴀʟᴀɴᴄᴇ:</b> <code>{current_points}</code> ᴘᴏɪɴᴛs\n\n"
        "<i>ᴄʜᴏᴏsᴇ ᴀɴ ɪɴᴠᴇɴᴛᴏʀʏ ᴘᴀᴄᴋᴀɢᴇ ʙᴇʟᴏᴡ ᴛᴏ ᴇxᴄʜᴀɴɢᴇ ʏᴏᴜʀ ᴘᴏɪɴᴛs:</i>"
    )
    await query.message.edit_text(store_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")

async def process_points_redemption(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = str(query.from_user.id)
    redeem_key = query.data.replace("claim_", "")
    item = REDEEM_PRODUCTS[redeem_key]
    
    db = load_referral_data()
    user_points = db.get(user_id, {}).get("points", 0)
    
    if user_points < item["points_cost"]:
        await query.message.reply_text(f"❌ <b>ʀᴇᴅᴇᴍᴘᴛɪᴏɴ ғᴀɪʟᴇᴅ!</b> ʏᴏᴜ ʜᴀᴠᴇ <code>{user_points}</code> ᴘᴏɪɴᴛs, ʙᴜᴛ ᴛʜɪs ɪᴛᴇᴍ ʀᴇǫᴜɪʀᴇs <code>{item['points_cost']}</code> ᴘᴏɪɴᴛs.", parse_mode="HTML")
        return
        
    stock_qty = get_stock_count(item["file"])
    if stock_qty < 1:
        await query.message.reply_text("❌ <b>ᴏᴜᴛ ᴏғ sᴛᴏᴄᴋ!</b> sᴏʀʀʏ, ᴛʜɪs ɪᴛᴇᴍ ɪs ᴛᴇᴍᴘᴏʀᴀʀɪʟʏ ᴏᴜᴛ ᴏғ sᴛᴏᴄᴋ.", parse_mode="HTML")
        return
        
    db[user_id]["points"] -= item["points_cost"]
    save_referral_data(db)
    
    claimed_code = extract_and_remove_codes(item["file"], 1)
    if not claimed_code:
        db[user_id]["points"] += item["points_cost"]
        save_referral_data(db)
        await query.message.reply_text("❌ sʏsᴛᴇᴍ ᴇʀʀᴏʀ ᴘʀᴏᴄᴇssɪɴɢ ʀᴇᴡᴀʀᴅ. ᴘᴏɪɴᴛs ʀᴇғᴜɴᴅᴇᴅ.")
        return
        
    delivery_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "🎉 <b>ᴘᴏɪɴᴛs ʀᴇᴅᴇᴍᴘᴛɪᴏɴ sᴜᴄᴄᴇssғᴜʟ</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"🎁 <b>ᴇxᴄʜᴀɴɢᴇᴅ ɪᴛᴇᴍ:</b> {item['name']}\n"
        f"📉 <b>ᴘᴏɪɴᴛs ᴅᴇᴅᴜᴄᴛᴇᴅ:</b> <code>{item['points_cost']}</code> Pts\n\n"
        f"🔑 <b>ʏᴏᴜʀ ᴄʟᴀɪᴍᴇᴅ ᴄᴏᴜᴘᴏɴ ᴄᴏᴅᴇ:</b>\n<code>{claimed_code[0]}</code>\n\n"
        "📌 <i>ᴛᴀᴘ ᴏɴ ᴛʜᴇ ᴄᴏᴅᴇ ᴀʙᴏᴠᴇ ᴛᴏ ᴄᴏᴘʏ ɪᴛ ɪɴsᴛᴀɴᴛʟʏ.</i>"
    )
    await context.bot.send_message(chat_id=int(user_id), text=delivery_text, parse_mode="HTML")
    await display_redemption_store(update, context)

async def display_filtered_catalog(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    category = query.data.replace("cat_", "")
    keyboard = []
    
    for key, item in PRODUCTS.items():
        if category == "coupons" and item["type"] == "coupon":
            keyboard.append([btn(item["name"], f"select_{key}", STYLE_S, ICO_GREEN)])
        elif category == "subs" and item["type"] == "subscription":
            keyboard.append([btn(item["name"], f"select_{key}", STYLE_P, ICO_BLUE)])
            
    keyboard.append([btn("🔙 ʙᴀᴄᴋ ᴛᴏ ᴄᴀᴛᴇɢᴏʀɪᴇs", "back_categories", STYLE_D, ICO_CANCEL)])
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await query.message.edit_text(
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "🛒 <b>ᴀᴠᴀɪʟᴀʙʟᴇ ᴄᴀᴛᴀʟᴏɢ ʟɪsᴛɪɴɢs</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        "<i>sᴇʟᴇᴄᴛ ᴀ ᴘʀᴏᴅᴜᴄᴛ ʙᴇʟᴏᴡ ᴛᴏ ᴘᴜʀᴄʜᴀsᴇ:</i>",
        reply_markup=reply_markup,
        parse_mode="HTML"
    )

async def handle_product_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    product_key = query.data.replace("select_", "")
    product = PRODUCTS[product_key]
    lines_per_unit = product.get("lines_per_unit", 1)
    
    current_stock = get_stock_count(product["file"], lines_per_unit)
    if current_stock < 1:
        await query.message.reply_text("❌ sᴏʀʀʏ, ᴛʜɪs ɪᴛᴇᴍ ɪs ᴄᴜʀʀᴇɴᴛʟʏ ᴏᴜᴛ ᴏғ sᴛᴏᴄᴋ!")
        return
        
    context.user_data["selected_product_key"] = product_key
    context.user_data["applied_promo_half"] = False  
    
    max_quick_range = min(4, current_stock)
    buttons = []
    for i in range(1, max_quick_range + 1):
        buttons.append(btn(f"🔢 {i}", f"qty_{i}", STYLE_P, ICO_BLUE))
    
    keyboard = [
        buttons,
        [btn("📝 ᴇɴᴛᴇʀ ᴄᴜsᴛᴏᴍ ǫᴜᴀɴᴛɪᴛʏ", "qty_custom_input", STYLE_S, ICO_GREEN)],
        [btn("✖ ᴄᴀɴᴄᴇʟ ᴏʀᴅᴇʀ", "checkout_cancel", STYLE_D, ICO_CANCEL)]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if product.get("price_tiered"):
        price_display = (
            f"\n💰 <b>ᴘʀɪᴄᴇ:</b> ₹{int(product['base_price'])} / unit (1–4 qty)\n"
            f"🔥 <b>ʙᴜʟᴋ ᴅɪsᴄᴏᴜɴᴛ:</b> ₹{int(product['bulk_price'])} / unit (5+ qty) ✅"
        )
    else:
        price_display = f"\n💰 <b>ᴘʀɪᴄᴇ:</b> ₹{int(product['price'])} / ᴘᴇʀ ᴜɴɪᴛ ✅"
    
    quantity_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "🔢 <b>sᴇʟᴇᴄᴛ ǫᴜᴀɴᴛɪᴛʏ</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"📦 <b>ɪᴛᴇᴍ:</b> {product['name']}{price_display}\n"
        f"📊 <b>ᴀᴠᴀɪʟᴀʙʟᴇ sᴛᴏᴄᴋ:</b> <code>{current_stock}</code> units\n\n"
        "<i>sᴇʟᴇᴄᴛ ᴀ sʜᴏʀᴛᴄᴜᴛ ᴏʀ ᴄʜᴏᴏsᴇ ᴄᴜsᴛᴏᴍ ɪɴᴘᴜᴛ:</i> 👇"
    )
    await query.message.edit_text(quantity_text, reply_markup=reply_markup, parse_mode="HTML")

async def handle_quantity_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    product_key = context.user_data.get("selected_product_key")
    if not product_key:
        await query.message.edit_text("❌ ᴏʀᴅᴇʀ sᴇssɪᴏɴ ᴇxᴘɪʀᴇᴅ. ᴘʟᴇᴀsᴇ ᴛᴀᴘ 🛸 ɢᴏ ᴛᴏ sᴛᴏʀᴇ ᴀɢᴀɪɴ.")
        return

    if query.data == "qty_custom_input":
        context.user_data["awaiting_custom_qty"] = True
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text="✏️ <b>ᴘʟᴇᴀsᴇ ᴇɴᴛᴇʀ ʏᴏᴜʀ ᴅᴇsɪʀᴇᴅ ᴘᴜʀᴄʜᴀsᴇ ǫᴜᴀɴᴛɪᴛʏ ʙᴇʟᴏᴡ:</b>",
            parse_mode="HTML"
        )
        return

    quantity = int(query.data.replace("qty_", ""))
    context.user_data["order_quantity"] = quantity
    await route_post_quantity_step(query.message, context, product_key, quantity, edit_mode=True)

async def route_post_quantity_step(message, context, product_key, quantity, edit_mode=True):
    if product_key == "gemini" and get_promo_uses() < 10:
        keyboard = [
            [btn("🎟️ ᴀᴘᴘʟʏ ᴘʀᴏᴍᴏ ᴄᴏᴅᴇ", "prompt_coupon", STYLE_P, ICO_BLUE)],
            [btn("⏩ sᴋɪᴘ & ᴘʀᴏᴄᴇᴇᴅ", "skip_coupon", STYLE_S, ICO_GREEN)]
        ]
        text = (
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            "🎟️ <b>ᴘʀᴏᴍᴏᴛɪᴏɴ ᴄᴏᴅᴇ ᴅᴇᴛᴇᴄᴛᴇᴅ</b>\n"
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
            "ᴡᴏᴜʟᴅ ʏᴏᴜ ʟɪᴋᴇ ᴛᴏ ᴀᴘᴘʟʏ ᴀ ᴘʀᴏᴍᴏᴛɪᴏɴ ᴄᴏᴅᴇ ᴛᴏ ᴛʜɪs ɢᴇᴍɪɴɪ ᴘʀᴇᴍɪᴜᴍ ᴏʀᴅᴇʀ?"
        )
        if edit_mode:
            await message.edit_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")
        else:
            await message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")
    else:
        await process_order_terms(message, context, product_key, quantity, edit_mode=edit_mode)

async def handle_coupon_prompt_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    context.user_data["awaiting_promo_code"] = True
    await context.bot.send_message(
        chat_id=query.message.chat_id,
        text="⌨️️ <b>ᴘʟᴇᴀsᴇ ᴇɴᴛᴇʀ ʏᴏᴜʀ ᴘʀᴏᴍᴏ ᴄᴏᴅᴇ ʜᴇʀᴇ ɪɴ ᴄʜᴀᴛ:</b>",
        parse_mode="HTML"
    )

async def handle_text_inputs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    input_text = update.message.text
    if not input_text:
        return

    # 🔐 Admin check for specific states
    if input_text.strip() == "👑 ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ" and update.message.from_user.id in ADMIN_IDS:
        await show_admin_panel_inline(update.message, context)
        return

    if context.user_data.get("awaiting_custom_qty"):
        product_key = context.user_data.get("selected_product_key")
        if not product_key or not input_text.isdigit() or int(input_text) <= 0:
            await update.message.reply_text("❌ ɪɴᴠᴀʟɪᴅ ɪɴᴘᴜᴛ! ᴘʀᴏᴠɪᴅᴇ ᴀ ᴘᴏsɪᴛɪᴠᴇ ɪɴᴛᴇɢᴇʀ ᴄᴏᴜɴᴛ:")
            return

        requested_qty = int(input_text)
        product = PRODUCTS[product_key]
        lines_per_unit = product.get("lines_per_unit", 1)
        current_stock = get_stock_count(product["file"], lines_per_unit)

        if requested_qty > current_stock:
            await update.message.reply_text(f"❌ ɪɴsᴜғғɪᴄɪᴇɴᴛ sᴛᴏᴄᴋ! ᴏɴʟʏ <code>{current_stock}</code> ᴜɴɪᴛs ʟᴇғᴛ:", parse_mode="HTML")
            return

        context.user_data["awaiting_custom_qty"] = False
        context.user_data["order_quantity"] = requested_qty
        await route_post_quantity_step(update.message, context, product_key, requested_qty, edit_mode=False)
        return

    if context.user_data.get("awaiting_promo_code"):
        product_key = context.user_data.get("selected_product_key")
        quantity = context.user_data.get("order_quantity", 1)
        context.user_data["awaiting_promo_code"] = False

        if input_text.strip() == VALID_PROMO_CODE:
            if get_promo_uses() < 10:
                context.user_data["applied_promo_half"] = True
                await update.message.reply_text("✅ <b>sᴜᴄᴄᴇss!</b> ᴘʀᴏᴍᴏ ᴀᴘᴘʟɪᴇᴅ: ᴇɴᴊᴏʏ 50% ᴏғғ ʏᴏᴜʀ ᴏʀᴅᴇʀ.", parse_mode="HTML")
            else:
                await update.message.reply_text("❌ ᴘʀᴏᴍᴏ ᴇxᴘɪʀᴇᴅ! ᴛʜɪs ᴄᴏᴅᴇ ʜᴀs ʀᴇᴀᴄʜᴇᴅ ɪᴛs 10-ʀᴇᴅᴇᴍᴘᴛɪᴏɴ ʟɪᴍɪᴛ.")
        else:
            await update.message.reply_text("❌ ɪɴᴠᴀʟɪᴅ ᴄᴏᴅᴇ ᴀᴘᴘʟɪᴇᴅ! ᴘʀᴏᴄᴇᴇᴅɪɴɢ ᴀᴛ sᴛᴀɴᴅᴀʀᴅ ʀᴀᴛᴇ.")

        await process_order_terms(update.message, context, product_key, quantity, edit_mode=False)
        return

async def process_order_terms(message, context, product_key, quantity, edit_mode=True):
    product = PRODUCTS[product_key]
    total_price, unit_rate = calculate_item_total(product_key, quantity)
    
    promo_badge = ""
    if product_key == "gemini" and context.user_data.get("applied_promo_half"):
        total_price = total_price / 2
        promo_badge = " 🔥 <i>(50% ᴘʀᴏᴍᴏ ᴀᴘᴘʟɪᴇᴅ)</i>"
    
    bulk_applied_note = ""
    if product.get("price_tiered") and quantity >= product.get("bulk_threshold", 5):
        bulk_applied_note = " ✨ <i>(🔥 Bulk rate applied!)</i>"
        
    terms_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "⚖️ <b>ᴛᴇʀᴍs & ᴄᴏɴᴅɪᴛɪᴏɴs</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"📦 <b>{product['name']} × {quantity}</b>\n"
        f"💰 ʀᴀᴛᴇ: ₹{int(unit_rate)} ᴘᴇʀ ᴜɴɪᴛ{bulk_applied_note}\n"
        f"💵 ᴛᴏᴛᴀʟ ᴘʀɪᴄᴇ: <b><code>₹{int(total_price)}.00</code></b>{promo_badge}\n\n"
        "📋 <b>ᴛᴇʀᴍs:</b>\n"
        "✦ ɴᴏ ʀᴇᴛᴜʀɴs ᴀғᴛᴇʀ ᴅᴇʟɪᴠᴇʀʏ\n"
        "✦ 100% ғʀᴇsʜ & ᴠᴇʀɪғɪᴇᴅ\n\n"
        "<i>ʙʏ ᴘʀᴏᴄᴇᴇᴅɪɴɢ, ʏᴏᴜ ᴀɢʀᴇᴇ ᴛᴏ ᴛʜᴇsᴇ ᴛᴇʀᴍs.</i>"
    )
    
    keyboard = [
        [btn("✅ ᴀɢʀᴇᴇ & ᴘʀᴏᴄᴇᴇᴅ ᴛᴏ ᴘᴀʏ", "checkout_proceed", STYLE_S, ICO_GREEN)],
        [btn("✖ ᴄᴀɴᴄᴇʟ", "checkout_cancel", STYLE_D, ICO_CANCEL)]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    if edit_mode:
        await message.edit_text(terms_text, reply_markup=reply_markup, parse_mode="HTML")
    else:
        await message.reply_text(terms_text, reply_markup=reply_markup, parse_mode="HTML")

async def display_secure_checkout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    product_key = context.user_data.get("selected_product_key")
    quantity = context.user_data.get("order_quantity", 1)
    
    if not product_key:
        await query.message.edit_text("❌ ᴏʀᴅᴇʀ sᴇssɪᴏɴ ᴇxᴘɪʀᴇᴅ. ᴘʟᴇᴀsᴇ ʀᴇsᴛᴀʀᴛ ᴠɪᴀ /start.")
        return

    product = PRODUCTS[product_key]
    total_price, _ = calculate_item_total(product_key, quantity)
    
    if product_key == "gemini" and context.user_data.get("applied_promo_half"):
        total_price = total_price / 2
        
    upi_uri = f"upi://pay?pa={UPI_ID}&pn={MERCHANT_NAME.replace(' ', '%20')}&am={total_price}&cu=INR&tn=Order_{product_key}"
    qr_scanner_url = f"https://quickchart.io/qr?text={upi_uri}&size=300"
    universal_web_pay_link = f"https://gpay.app.goo.gl/pay?pa={UPI_ID}&pn={MERCHANT_NAME.replace(' ', '%20')}&am={total_price}&cu=INR"
    
    checkout_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "💳 <b>sᴇᴄᴜʀᴇ ᴄʜᴇᴄᴋᴏᴜᴛ</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        f"📦 ɪᴛᴇᴍ: {product['name']}\n"
        f"🔢 ǫᴜᴀɴᴛɪᴛʏ: {quantity} units\n"
        f"💰 ᴛᴏᴛᴀʟ ᴀᴍᴏᴜɴᴛ: ₹{int(total_price)}.00\n\n"
        f"<b>ᴜᴘɪ ɪᴅ:</b> <code>{UPI_ID}</code>\n\n"
        "<b>ʜᴏᴡ ᴛᴏ ᴘᴀʏ:</b>\n"
        "1️⃣ sᴄᴀɴ ᴛʜᴇ ǫʀ ᴄᴏᴅᴇ ɪᴍᴀɢᴇ ᴀʙᴏᴠᴇ\n"
        "2️⃣ ᴘᴀʏ ᴇxᴀᴄᴛʟʏ ᴛʜᴇ ᴛᴏᴛᴀʟ ᴀᴍᴏᴜɴᴛ ᴅɪsᴘʟᴀʏᴇᴅ\n"
        "3️⃣ ᴛᴀᴘ '✅ ɪ ʜᴀᴠᴇ ᴘᴀɪᴅ' ʙᴇʟᴏᴡ\n\n"
        "⏳ <i>ᴄʜᴇᴄᴋᴏᴜᴛ sᴇssɪᴏɴ ᴇxᴘɪʀᴇs ɪɴ 5 ᴍɪɴᴜᴛᴇs.</i>"
    )
    
    keyboard = [
        [btn("📱 ᴏᴘᴇɴ ᴜᴘɪ ᴀᴘᴘ ᴅɪʀᴇᴄᴛ", universal_web_pay_link, STYLE_P, ICO_BLUE)],
        [btn("✅ ɪ ʜᴀᴠᴇ ᴘᴀɪᴅ", "verify_payment_done", STYLE_S, ICO_GREEN)]
    ]
    await query.message.delete()
    await context.bot.send_photo(chat_id=query.message.chat_id, photo=qr_scanner_url, caption=checkout_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")

async def request_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = str(query.from_user.id)
    pending = load_pending_uploads()
    pending[user_id] = True
    save_pending_uploads(pending)

    await context.bot.send_message(
        chat_id=query.message.chat_id,
        text="▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📸 <b>ᴜᴘʟᴏᴀᴅ ʀᴇᴄᴇɪᴘᴛ</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\nᴘʟᴇᴀsᴇ sᴜʙᴍɪᴛ ᴀ ᴄʟᴇᴀʀ sᴄʀᴇᴇɴsʜᴏᴛ ᴏғ ʏᴏᴜʀ ᴘᴀʏᴍᴇɴᴛ ʀᴇᴄᴇɪᴘᴛ ʙᴇʟᴏᴡ:",
        parse_mode="HTML"
    )

async def handle_screenshot_submission(update: Update, context: ContextTypes.DEFAULT_TYPE):
    buyer = update.message.from_user
    user_id = str(buyer.id)

    pending = load_pending_uploads()
    if not pending.get(user_id):
        return

    photo_file_id = None
    if update.message.photo:
        photo_file_id = update.message.photo[-1].file_id
    elif update.message.document and update.message.document.mime_type and update.message.document.mime_type.startswith("image"):
        photo_file_id = update.message.document.file_id

    if not photo_file_id:
        return

    product_key = context.user_data.get("selected_product_key", "swiggy_160")
    quantity = context.user_data.get("order_quantity", 1)
    promo_used = "Yes" if context.user_data.get("applied_promo_half") else "No"
    
    product = PRODUCTS.get(product_key, PRODUCTS["swiggy_160"])
    total_price, _ = calculate_item_total(product_key, quantity)
    
    if promo_used == "Yes":
        total_price = total_price / 2

    buyer_username = buyer.username or buyer.first_name or "Unknown"
    buyer_first_name = buyer.first_name or "User"
    
    # Clear pending upload lock
    pending[user_id] = False
    save_pending_uploads(pending)

    _, full_time_str = get_ist_time_details()

    await update.message.reply_text(
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n⏳ <b>ᴘᴀʏᴍᴇɴᴛ ᴜɴᴅᴇʀ ᴠᴇʀɪғɪᴄᴀᴛɪᴏɴ</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        "ʏᴏᴜʀ ᴘᴀʏᴍᴇɴᴛ ʀᴇᴄᴇɪᴘᴛ ʜᴀs ʙᴇᴇɴ ʀᴇᴄᴇɪᴠᴇᴅ. ʏᴏᴜʀ ᴄᴏᴅᴇ ᴡɪʟʟ ʙᴇ ᴅᴇʟɪᴠᴇʀᴇᴅ ᴀs sᴏᴏɴ ᴀs ɪᴛ ɪs ᴠᴇʀɪғɪᴇᴅ.",
        parse_mode="HTML"
    )

    unique_suffix = uuid.uuid4().hex[:6]
    order_id = f"{buyer.id}_{unique_suffix}"

    admin_markup = InlineKeyboardMarkup([
        [btn("✅ Approve & Send Code", f"adm_approve:{order_id}:{product_key}:{quantity}:{promo_used}:{buyer_username}", STYLE_S, ICO_GREEN)],
        [btn("❌ Reject Payment", f"adm_reject:{order_id}", STYLE_D, ICO_CANCEL)]
    ])

    admin_panel_text = (
        f"🚨 <b>NEW SHOP ORDER</b> 🚨\n\n"
        f"🕒 <b>Time:</b> {full_time_str}\n"
        f"👤 <b>Buyer:</b> {html.escape(buyer_first_name)} (@{html.escape(str(buyer_username))}) (<code>{buyer.id}</code>)\n"
        f"📦 <b>Product:</b> {html.escape(product['name'])}\n"
        f"🔢 <b>Qty:</b> {quantity}\n"
        f"🎟️ <b>Promo:</b> {promo_used}\n"
        f"💰 <b>Total:</b> ₹{int(total_price)}.00"
    )

    orders_database = load_admin_orders()
    orders_database[order_id] = []

    # Send admin alerts independently to guarantee delivery
    for admin_id in ADMIN_IDS:
        try:
            msg = await context.bot.send_photo(
                chat_id=admin_id, 
                photo=photo_file_id, 
                caption=admin_panel_text, 
                reply_markup=admin_markup, 
                parse_mode="HTML"
            )
            orders_database[order_id].append({"chat_id": admin_id, "message_id": msg.message_id})
        except Exception as e:
            logging.error(f"Failed to alert admin ID {admin_id}: {e}")

    save_admin_orders(orders_database)

async def handle_admin_actions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user_id = update.callback_query.from_user.id
    if user_id not in ADMIN_IDS:
        return
        
    data = query.data
    _, action_time = get_ist_time_details()
    
    if data.startswith("adm_approve:"):
        parts = data.split(":")
        order_id = parts[1]
        buyer_id = int(order_id.split("_")[0])
        product_key = parts[2]
        quantity = int(parts[3])
        promo_used = parts[4]
        buyer_username = parts[5] if len(parts) > 5 else "Unknown User"
        
        orders_database = load_admin_orders()
        matching_messages = orders_database.get(order_id, [])

        if product_key == "gemini" and promo_used == "Yes":
            if get_promo_uses() >= 10:
                for link in matching_messages:
                    try:
                        await context.bot.edit_message_caption(chat_id=link["chat_id"], message_id=link["message_id"], caption="⚠️ <b>PROMO EXPIRED:</b> Cap reached during verification loop.", parse_mode="HTML")
                    except TelegramError:
                        pass
                return
            record_promo_use(buyer_id)

        product = PRODUCTS[product_key]
        lines_per_unit = product.get("lines_per_unit", 1)
        purchased_codes = extract_and_remove_codes(product["file"], quantity, lines_per_unit)
        if not purchased_codes:
            for link in matching_messages:
                try:
                    await context.bot.edit_message_caption(chat_id=link["chat_id"], message_id=link["message_id"], caption="⚠️ <b>STOCK OUT:</b> Processing aborted due to empty inventory file.", parse_mode="HTML")
                except TelegramError:
                    pass
            return

        # Formatting the Codes for Delivery
        if lines_per_unit == 2:
            grouped_units = []
            for i in range(0, len(purchased_codes), 2):
                pair = purchased_codes[i:i+2]
                grouped_units.append(f"<code>{html.escape(pair[0])}</code>\n<code>{html.escape(pair[1])}</code>")
            formatted_codes_list = "\n\n".join(grouped_units)
        else:
            formatted_codes_list = "\n\n".join([f"<code>{html.escape(code)}</code>" for code in purchased_codes])
        
        delivery_text = (
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            "🎉 <b>ᴏʀᴅᴇʀ ᴠᴇʀɪғɪᴇᴅ & ᴅᴇʟɪᴠᴇʀᴇᴅ</b>\n"
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
            "✅ ʏᴏᴜʀ ᴘᴀʏᴍᴇɴᴛ sᴛᴀᴛᴜs ʜᴀs ʙᴇᴇɴ ᴀᴘᴘʀᴏᴠᴇᴅ!\n\n"
            f"📦 <b>ɪᴛᴇᴍ:</b> {product['name']}\n"
            f"🔢 <b>ǫᴜᴀɴᴛɪᴛʏ:</b> {quantity} unit(s)\n\n"
            f"🔑 <b>ʏᴏᴜʀ ᴘʀᴏᴅᴜᴄᴛ ᴠᴏᴜᴄʜᴇʀ/ᴀᴄᴄᴇss ᴄᴏᴅᴇ:</b>\n\n{formatted_codes_list}\n\n"
            "<i>ᴛʜᴀɴᴋ ʏᴏᴜ ғᴏʀ ᴄʜᴏᴏsɪɴɢ ᴘᴏᴡᴇʀxꜱʜᴏᴘ!</i>"
        )
        
        buyer_notified = False
        total_revenue, _ = calculate_item_total(product_key, quantity)
        if product_key == "gemini" and promo_used == "Yes":
            total_revenue /= 2.0

        try:
            # 🔥 Bug Fix: Send as document if codes exceed 3500 chars (e.g., 4+ quantities)
            if len(delivery_text) > 3500:
                file_bytes = io.BytesIO(delivery_text.encode("utf-8"))
                file_bytes.name = f"Order_{order_id}.txt"
                await context.bot.send_document(
                    chat_id=buyer_id,
                    document=file_bytes,
                    caption=f"✅ <b>ᴏʀᴅᴇʀ ᴠᴇʀɪғɪᴇᴅ & ᴅᴇʟɪᴠᴇʀᴇᴅ</b>\n\n📦 <b>ɪᴛᴇᴍ:</b> {product['name']}\n🔢 <b>ǫᴜᴀɴᴛɪᴛʏ:</b> {quantity}\n\n<i>Kripya attached file se apne codes copy karein.</i>",
                    parse_mode="HTML"
                )
            else:
                await context.bot.send_message(chat_id=buyer_id, text=delivery_text, parse_mode="HTML")
                
            buyer_notified = True
            record_sales_stat(buyer_id, buyer_username, product_key, quantity, total_revenue)
            
        except TelegramError as e:
            logging.error(f"Delivery failed to {buyer_id}: {e}")

        admin_summary = f"✅ <b>Approved by Admin {user_id}</b>\n🕒 Time: {action_time}\n📦 Delivered to buyer: <code>{buyer_id}</code>" if buyer_notified else f"❌ <b>Error:</b> Codes extracted but user <code>{buyer_id}</code> blocked bot."
        for link in matching_messages:
            try:
                await context.bot.edit_message_caption(chat_id=link["chat_id"], message_id=link["message_id"], caption=admin_summary, reply_markup=None, parse_mode="HTML")
            except TelegramError:
                pass

        if order_id in orders_database:
            del orders_database[order_id]
        save_admin_orders(orders_database)

    elif data.startswith("adm_reject:"):
        parts = data.split(":")
        order_id = parts[1]
        buyer_id = int(order_id.split("_")[0])

        orders_database = load_admin_orders()
        matching_messages = orders_database.get(order_id, [])

        try:
            await context.bot.send_message(chat_id=buyer_id, text="❌ <b>ᴘᴀʏᴍᴇɴᴛ ʀᴇᴊᴇᴄᴛᴇᴅ.</b> ᴏᴜʀ ᴀᴄᴄᴏᴜɴᴛɪɴɢ ᴅᴇsᴋ ᴄᴏᴜʟᴅ ɴᴏᴛ ʟᴏᴄᴀᴛᴇ ᴛʜɪs ᴄʀᴇᴅɪᴛ.", parse_mode="HTML")
        except TelegramError:
            pass

        admin_summary = f"❌ <b>Rejected by Admin {user_id}</b>\n🕒 Time: {action_time}\n👤 User: <code>{buyer_id}</code>"
        for link in matching_messages:
            try:
                await context.bot.edit_message_caption(chat_id=link["chat_id"], message_id=link["message_id"], caption=admin_summary, reply_markup=None, parse_mode="HTML")
            except TelegramError:
                pass

        if order_id in orders_database:
            del orders_database[order_id]
        save_admin_orders(orders_database)

    # --- ADMIN PANEL INLINE BUTTONS ---
    elif data == "adm_panel_stats":
        stats = load_sales_stats()
        today_date, current_time_str = get_ist_time_details()
        date_data = stats.get(today_date, {})
        
        daily_rev = date_data.get("daily_revenue", 0.0)
        orders = date_data.get("orders", [])
        
        total_stock_swiggy = get_stock_count(PRODUCTS["swiggy_160"]["file"])
        total_stock_meesho = get_stock_count(PRODUCTS["meesho_170"]["file"])
        
        stats_text = (
            f"📊 <b>ᴀᴅᴍɪɴ sᴛᴀᴛs ({today_date})</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🕒 <b>Time:</b> {current_time_str}\n"
            f"💵 <b>Today's Revenue:</b> ₹{int(daily_rev)}.00\n"
            f"📦 <b>Today's Orders:</b> {len(orders)}\n\n"
            f"📦 <b>ᴄᴜʀʀᴇɴᴛ sᴛᴏᴄᴋ</b>\n"
            f"• Swiggy 160: <b>{total_stock_swiggy}</b> units\n"
            f"• Meesho 170: <b>{total_stock_meesho}</b> units\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"<i>Use 'Add Stock' to upload a new .txt file.</i>"
        )
        kb_stats = kb([btn("🔙 Back to Admin Panel", "adm_panel_home", STYLE_D, ICO_CANCEL)])
        await query.message.edit_text(stats_text, reply_markup=kb_stats, parse_mode="HTML")
        
    elif data == "adm_panel_addstock":
        add_text = (
            "📦 <b>ᴀᴅᴅ sᴛᴏᴄᴋ</b>\n\n"
            "Select which product you want to add stock for. "
            "You will then be prompted to upload a `.txt` file containing the JSONs."
        )
        kb_add = kb(
            [btn("💙 Swiggy 160", "adm_stock_swiggy_160", STYLE_S, ICO_GREEN)],
            [btn("💜 Meesho 170", "adm_stock_meesho_170", STYLE_S, ICO_GREEN)],
            [btn("🔙 Back to Admin Panel", "adm_panel_home", STYLE_D, ICO_CANCEL)]
        )
        await query.message.edit_text(add_text, reply_markup=kb_add, parse_mode="HTML")
        
    elif data.startswith("adm_stock_"):
        product_key = data.replace("adm_stock_", "")
        context.user_data["awaiting_admin_stock"] = product_key
        await query.message.edit_text(
            f"📄 <b>ᴜᴘʟᴏᴀᴅ sᴛᴏᴄᴋ ꜰɪʟᴇ ꜰᴏʀ {PRODUCTS[product_key]['name']}</b>\n\n"
            f"Please send the `.txt` file now. The bot will automatically read it and append it to the database.",
            reply_markup=kb([btn("❌ Cancel", "adm_panel_home", STYLE_D, ICO_CANCEL)])
        )

    elif data == "adm_panel_home":
        await show_admin_panel_inline(query.message, context, edit=True)

async def show_admin_panel_inline(message, context: ContextTypes.DEFAULT_TYPE, edit=False):
    if message.from_user.id not in ADMIN_IDS:
        return
        
    text = (
        "👑 <b>ᴀᴅᴍɪɴ ᴄᴏɴᴛʀᴏʟ ᴘᴀɴᴇʟ</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        "Welcome to the central admin hub. What would you like to do?"
    )
    kb_admin = kb(
        [btn("📊 View Stats", "adm_panel_stats", STYLE_P, ICO_BLUE)],
        [btn("📦 Add Stock (Upload .txt)", "adm_panel_addstock", STYLE_S, ICO_GREEN)]
    )
    
    if edit:
        await message.edit_text(text, reply_markup=kb_admin, parse_mode="HTML")
    else:
        await message.reply_text(text, reply_markup=kb_admin, parse_mode="HTML")

# --- STOCK UPLOAD DOCUMENT HANDLER ---
async def handle_admin_stock_upload(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id not in ADMIN_IDS:
        return
        
    product_key = context.user_data.get("awaiting_admin_stock")
    if not product_key:
        return
        
    doc = update.message.document
    if not doc or not doc.file_name.endswith(".txt"):
        await update.message.reply_text("❌ Please upload a valid `.txt` file.")
        return
        
    await update.message.reply_text("⏳ Parsing your file and adding to stock...")
    
    try:
        file = await context.bot.get_file(doc.file_id)
        file_bytes = await file.download_as_bytearray()
        content = file_bytes.decode("utf-8", errors="ignore")
        
        # Append to file
        filepath = get_file_path(PRODUCTS[product_key]["file"])
        with open(filepath, "a", encoding="utf-8") as f:
            f.write("\n\n" + content.strip())
            
        context.user_data["awaiting_admin_stock"] = None
        
        new_stock = get_stock_count(PRODUCTS[product_key]["file"])
        await update.message.reply_text(
            f"✅ <b>Stock Successfully Added!</b>\n\n"
            f"📦 <b>Product:</b> {PRODUCTS[product_key]['name']}\n"
            f"📊 <b>New Total Stock:</b> <b>{new_stock}</b> units",
            parse_mode="HTML"
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Error processing file: {e}")

async def cancel_checkout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.message.edit_text("❌ ᴏʀᴅᴇʀ ᴄᴀɴᴄᴇʟʟᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ. ᴜsᴇ ᴛʜᴇ ᴍᴇɴᴜ ᴛᴏ ʙʀᴏᴡsᴇ ᴀɢᴀɪɴ.")

async def show_support_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    support_text = (
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n🛠️ <b>ᴄᴜsᴛᴏᴍᴇʀ sᴜᴘᴘᴏʀᴛ ᴄᴇɴᴛʀᴇ</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
        "💬 <i>ғᴏʀ ᴀɴʏ ʜᴇʟᴘ, ᴄᴏɴᴛᴀᴄᴛ ᴏᴜʀ sᴜᴘᴘᴏʀᴛ ʙᴏᴛ ᴅɪʀᴇᴄᴛʟʏ:</i>"
    )
    keyboard = [[btn("💬 ᴄᴏɴɴᴇᴄᴛ ᴛᴏ sᴜᴘᴘᴏʀᴛ ʙᴏᴛ", "https://t.me/PowerXSupport_Bot", STYLE_P, ICO_BLUE)]]
    await update.message.reply_text(support_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="HTML")

# ─────────────────────────────────────────────────────────────
#  Broadcast System (Restored + File Support)
# ─────────────────────────────────────────────────────────────
async def broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id not in ADMIN_IDS:
        return

    message_to_send = ""
    
    # 1. Check if replying to a .txt file
    if update.message.reply_to_message and update.message.reply_to_message.document:
        doc = update.message.reply_to_message.document
        if doc.file_name.endswith(".txt"):
            await update.message.reply_text("⏳ Reading broadcast text from attached file...")
            try:
                file = await context.bot.get_file(doc.file_id)
                file_bytes = await file.download_as_bytearray()
                message_to_send = file_bytes.decode("utf-8", errors="ignore").strip()
            except Exception as e:
                await update.message.reply_text(f"❌ Failed to read file: {e}")
                return
        else:
            await update.message.reply_text("❌ Please reply to a `.txt` file.")
            return
    else:
        # 2. Standard text broadcast
        raw_text = update.message.text
        match = re.match(r"^/broadcast\s+(.*)", raw_text, re.DOTALL | re.IGNORECASE)
        if not match:
            await update.message.reply_text("❌ <b>Usage Format:</b>\n<code>/broadcast &lt;Your Text Here&gt;</code>\n\n<i>Or reply to a .txt file with /broadcast</i>", parse_mode="HTML")
            return
        message_to_send = match.group(1)

    if not message_to_send:
        await update.message.reply_text("❌ Broadcast message is empty.")
        return

    filepath = get_file_path(USER_DB_FILE)
    if not os.path.exists(filepath):
        await update.message.reply_text("❌ No users found in the database yet.")
        return

    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        users = [line.strip() for line in f.readlines() if line.strip()]

    await update.message.reply_text(f"⏳ Broadcasting HTML message to {len(users)} users...")
    success_count, fail_count = 0, 0

    for uid in users:
        try:
            await context.bot.send_message(chat_id=int(uid), text=message_to_send, parse_mode="HTML")
            success_count += 1
        except TelegramError:
            fail_count += 1
        await asyncio.sleep(0.05)

    await update.message.reply_text(f"📢 <b>Broadcast Complete!</b>\n\n✅ Sent: {success_count}\n❌ Blocked: {fail_count}", parse_mode="HTML")

def main() -> None:
    application = Application.builder().token(BOT_TOKEN).connect_timeout(30.0).read_timeout(30.0).build()

    # Core commands
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("broadcast", broadcast_message))

    # Priority Match keyboard menu triggers
    application.add_handler(MessageHandler(filters.Text(["🛸 ɢᴏ ᴛᴏ sᴛᴏʀᴇ", "🛸 Go To Store"]), show_main_categories))
    application.add_handler(MessageHandler(filters.Text(["🛠️ sᴜᴘᴘᴏʀᴛ", "🛠️ Support"]), show_support_menu))
    
    # Catch photo receipts
    application.add_handler(MessageHandler(filters.PHOTO | filters.Document.IMAGE, handle_screenshot_submission))
    
    # Admin stock document upload
    application.add_handler(MessageHandler(filters.Document.FileExtension("txt"), handle_admin_stock_upload))

    # General catch-all for text inputs
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_inputs))

    # Callback inline grid navigators
    application.add_handler(CallbackQueryHandler(check_join_callback, pattern="^check_join$"))
    application.add_handler(CallbackQueryHandler(show_main_categories_callback, pattern="^back_categories$"))
    application.add_handler(CallbackQueryHandler(display_referral_panel, pattern="^refer_earn_menu$")) 
    application.add_handler(CallbackQueryHandler(display_redemption_store, pattern="^redeem_points_store$")) 
    application.add_handler(CallbackQueryHandler(process_points_redemption, pattern="^claim_")) 
    application.add_handler(CallbackQueryHandler(display_filtered_catalog, pattern="^cat_"))
    application.add_handler(CallbackQueryHandler(handle_product_selection, pattern="^select_"))
    application.add_handler(CallbackQueryHandler(handle_quantity_callback, pattern="^(qty_|qty_custom_input)"))
    application.add_handler(CallbackQueryHandler(handle_coupon_prompt_callback, pattern="^prompt_coupon$"))
    
    # Post coupon routing decisions fallback links
    application.add_handler(CallbackQueryHandler(lambda u, c: process_order_terms(u.callback_query.message, c, c.user_data.get("selected_product_key"), c.user_data.get("order_quantity", 1), True), pattern="^skip_coupon$"))
    application.add_handler(CallbackQueryHandler(display_secure_checkout, pattern="^checkout_proceed$"))
    application.add_handler(CallbackQueryHandler(cancel_checkout, pattern="^checkout_cancel$"))
    application.add_handler(CallbackQueryHandler(request_screenshot, pattern="^verify_payment_done$"))
    
    # Admin actions (Approve, Reject, Panel, Stats, AddStock)
    application.add_handler(CallbackQueryHandler(handle_admin_actions, pattern="^(adm_|adm_panel|adm_stock)"))

    print("PowerXShop Active - Broadcast Fixed, Admin Panel, Stock Uploader, 4+ Qty Fix...")
    application.run_polling()

if __name__ == "__main__":
    main()